# Load the tools
library(devtools)

# This will now work because it can read the plain text DESCRIPTION file
devtools::document() 



# This installs the package to your library
devtools::install()



