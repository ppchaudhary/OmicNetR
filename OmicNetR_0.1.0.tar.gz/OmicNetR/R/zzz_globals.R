utils::globalVariables(c(
  "Feature",
  "Loading",
  "Type",
  "Weight_Product"
))

